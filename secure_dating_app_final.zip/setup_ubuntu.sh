#!/bin/bash

# Ubuntu Setup Script for Secure Dating App

# Exit immediately if a command exits with a non-zero status.
set -e

PROJECT_DIR="/home/ubuntu/secure_dating_app"
PYTHON_VERSION="python3.11"
VENV_DIR="$PROJECT_DIR/venv"

echo "--- Setting up Secure Dating App on Ubuntu ---"

# 1. Check if Python 3.11 and venv are installed
if ! command -v $PYTHON_VERSION &> /dev/null
then
    echo "Error: $PYTHON_VERSION could not be found. Please install Python 3.11."
    exit 1
fi

if ! $PYTHON_VERSION -m venv --help &> /dev/null
then
    echo "Error: Python 3.11 venv module not found. Please install python3.11-venv."
    echo "Example: sudo apt update && sudo apt install python3.11-venv"
    exit 1
fi

echo "[1/5] Creating Python virtual environment..."
if [ ! -d "$VENV_DIR" ]; then
    $PYTHON_VERSION -m venv "$VENV_DIR"
    echo "Virtual environment created at $VENV_DIR"
else
    echo "Virtual environment already exists at $VENV_DIR"
fi

# Activate virtual environment for subsequent commands
source "$VENV_DIR/bin/activate"

echo "[2/5] Installing dependencies from requirements.txt..."
if [ -f "$PROJECT_DIR/requirements.txt" ]; then
    pip install -r "$PROJECT_DIR/requirements.txt"
else
    echo "Error: requirements.txt not found in $PROJECT_DIR"
    deactivate
    exit 1
fi

echo "[3/5] Setting up .env file..."
if [ ! -f "$PROJECT_DIR/.env" ]; then
    echo "Creating default .env file..."
    # Create a basic .env file if it doesn't exist, prompting user to fill DJANGO_SECRET_KEY
    cat << EOF > "$PROJECT_DIR/.env"
# Django Settings
DJANGO_SECRET_KEY= # <-- IMPORTANT: GENERATE A STRONG SECRET KEY HERE
DJANGO_DEBUG=True
DJANGO_ALLOWED_HOSTS="localhost 127.0.0.1"

# Database Settings (Default: SQLite)
DB_ENGINE=django.db.backends.sqlite3
DB_NAME=db.sqlite3

# Database Settings (Example: PostgreSQL - uncomment and configure if needed)
# DB_ENGINE=django.db.backends.postgresql
# DB_NAME=secure_dating_db
# DB_USER=your_db_user
# DB_PASSWORD=your_db_password
# DB_HOST=localhost
# DB_PORT=5432

# Security Headers (Set to True for HTTPS deployment)
CSRF_COOKIE_SECURE=False
SESSION_COOKIE_SECURE=False
SECURE_SSL_REDIRECT=False
SECURE_HSTS_SECONDS=0
SECURE_HSTS_INCLUDE_SUBDOMAINS=False
SECURE_HSTS_PRELOAD=False

# Toggleable Vulnerabilities (Set to True to enable)
ENABLE_IDOR_VULNERABILITY=False
ENABLE_SQLI_VULNERABILITY=False
ENABLE_XSS_VULNERABILITY=False
DISABLE_CSRF_PROTECTION=False
EOF
    echo "IMPORTANT: Please edit the .env file ($PROJECT_DIR/.env) and set a unique DJANGO_SECRET_KEY."
else
    echo ".env file already exists."
    # Check if DJANGO_SECRET_KEY is empty or default
    if grep -q "DJANGO_SECRET_KEY=\"\"" "$PROJECT_DIR/.env" || grep -q "DJANGO_SECRET_KEY=$" "$PROJECT_DIR/.env"; then
        echo "WARNING: DJANGO_SECRET_KEY in .env is empty. Please set a unique key."
    fi
fi

echo "[4/5] Applying database migrations..."
python "$PROJECT_DIR/manage.py" migrate

echo "[5/5] Setup complete!"

# Optional: Create a superuser
read -p "Do you want to create a superuser now? (y/N): " createsuperuser
if [[ "$createsuperuser" =~ ^[Yy]$ ]]
then
    echo "Creating superuser..."
    python "$PROJECT_DIR/manage.py" createsuperuser
fi

echo "---"
echo "To run the development server:"
echo "1. Activate the virtual environment: source $VENV_DIR/bin/activate"
echo "2. Run the server: python $PROJECT_DIR/manage.py runserver"
echo "Then access the application at http://127.0.0.1:8000/"

# Deactivate environment if script sourced, otherwise it exits anyway
deactivate &> /dev/null || true
