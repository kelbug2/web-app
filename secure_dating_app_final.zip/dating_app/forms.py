from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from .models import UserProfile

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True, help_text="Required. Inform a valid email address.")

    class Meta(UserCreationForm.Meta):
        model = User
        fields = UserCreationForm.Meta.fields + ("email",)

class CustomAuthenticationForm(AuthenticationForm):
    # You can customize the login form here if needed,
    # but the default AuthenticationForm is usually sufficient.
    pass

class UserProfileForm(forms.ModelForm):
    # Add fields from User model if needed, e.g., email
    # email = forms.EmailField(required=True)

    class Meta:
        model = UserProfile
        fields = [
            "orientation", "gender", "age", "bio",
            "photo1", "photo2", "photo3", # Consider using ImageField later
            "preferred_orientation", "preferred_gender",
            "min_age_preference", "max_age_preference"
        ]
        widgets = {
            "bio": forms.Textarea(attrs={"rows": 4}),
            # Add widgets for other fields if needed, e.g., Select for choices
        }

    # If you need to update User fields like email along with profile:
    # def __init__(self, *args, **kwargs):
    #     super().__init__(*args, **kwargs)
    #     if self.instance and self.instance.user:
    #         self.fields["email"].initial = self.instance.user.email

    # def save(self, commit=True):
    #     user = self.instance.user
    #     user.email = self.cleaned_data["email"]
    #     if commit:
    #         user.save()
    #     return super().save(commit=commit)
