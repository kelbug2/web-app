from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

# Create your models here.

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    # Personal Details
    orientation = models.CharField(max_length=100, blank=True, null=True)
    gender = models.CharField(max_length=50, blank=True, null=True)
    age = models.PositiveIntegerField(blank=True, null=True)
    bio = models.TextField(blank=True, null=True)
    # For simplicity, store photo URLs or paths. In a real app, use ImageField.
    # Using TextField for now to avoid Pillow dependency unless needed later.
    photo1 = models.TextField(blank=True, null=True) # Placeholder for photo path/URL
    photo2 = models.TextField(blank=True, null=True)
    photo3 = models.TextField(blank=True, null=True)

    # Match Preferences (Simplified)
    preferred_orientation = models.CharField(max_length=100, blank=True, null=True)
    preferred_gender = models.CharField(max_length=50, blank=True, null=True)
    min_age_preference = models.PositiveIntegerField(default=18)
    max_age_preference = models.PositiveIntegerField(default=99)

    # Role (Simplified - could use Django groups/permissions for more complex roles)
    ROLE_CHOICES = (
        ("user", "Regular User"),
        ("moderator", "Moderator"),
        ("admin", "Admin"),
    )
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default="user")

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username}\'s Profile"

# Signal to create or update UserProfile whenever a User instance is saved.
@receiver(post_save, sender=User)
def create_or_update_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)
    instance.profile.save()

# Basic Message model for chat
class Message(models.Model):
    sender = models.ForeignKey(User, related_name="sent_messages", on_delete=models.CASCADE)
    recipient = models.ForeignKey(User, related_name="received_messages", on_delete=models.CASCADE)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    def __str__(self):
        return f"From {self.sender.username} to {self.recipient.username} at {self.timestamp}"

    class Meta:
        ordering = ["timestamp"]

# Basic Match model
class Match(models.Model):
    user1 = models.ForeignKey(User, related_name="matches_initiated", on_delete=models.CASCADE)
    user2 = models.ForeignKey(User, related_name="matches_received", on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user1", "user2") # Ensure a match isn't duplicated
        verbose_name_plural = "Matches"

    def __str__(self):
        return f"Match between {self.user1.username} and {self.user2.username}"

# Audit Log Model
class AuditLog(models.Model):
    ACTION_CHOICES = (
        ("login_success", "Login Success"),
        ("login_fail", "Login Fail"),
        ("profile_update", "Profile Update"),
        ("message_sent", "Message Sent"),
        # Add other actions as needed
    )
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    action = models.CharField(max_length=50, choices=ACTION_CHOICES)
    timestamp = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    details = models.TextField(blank=True, null=True)

    def __str__(self):
        user_str = self.user.username if self.user else "System/Unknown"
        return f"{self.timestamp} - {user_str} - {self.action}"

    class Meta:
        ordering = ["-timestamp"]
