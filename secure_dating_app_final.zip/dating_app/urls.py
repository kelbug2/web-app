from django.urls import path
from . import views

# Define URL patterns for the dating_app
urlpatterns = [
    # Home page
    path("", views.home, name="home"),
    # Authentication URLs (Step 5)
    path("register/", views.register, name="register"),
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    # Profile URLs (Step 6)
    path("profile/", views.profile_view, name="profile"),
    path("profile/edit/", views.profile_edit, name="profile_edit"),
    # Matching/Messaging URLs (Step 7)
    path("users/", views.users_list, name="users_list"),
    path("like/<int:user_id>/", views.like_user, name="like_user"),
    path("matches/", views.matches_view, name="matches"),
    path("chat/<str:username>/", views.chat_view, name="chat"),
    # Removed Vulnerability demonstration URLs (Step 9)
    # path("idor_example/<int:user_id>/", views.idor_vulnerability_view, name="idor_example"),
    # path("sqli_example/", views.sqli_vulnerability_view, name="sqli_example"),
]
