from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseForbidden, JsonResponse, Http404
from django.contrib.auth.models import User
from django.contrib import messages
from .forms import CustomUserCreationForm, CustomAuthenticationForm, UserProfileForm
from .models import AuditLog, UserProfile, Match, Message
from django.db.models import Q
# Removed: from django.db import connection # For raw SQL example
from django.utils.html import escape # For XSS prevention (though default in templates)
# Removed: from django.views.decorators.csrf import csrf_exempt # For CSRF toggle
# Removed: from django.conf import settings # No longer needed for vulnerability toggles
import os

# Helper function to get client IP
def get_client_ip(request):
    x_forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
    if x_forwarded_for:
        ip = x_forwarded_for.split(",")[0]
    else:
        ip = request.META.get("REMOTE_ADDR")
    return ip

# Create your views here.

def home(request):
    """View for the home page."""
    return render(request, "dating_app/home.html")

# --- Authentication Views (Step 5) ---
def register(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user, backend="django.contrib.auth.backends.ModelBackend")
            AuditLog.objects.create(user=user, action="login_success", ip_address=get_client_ip(request), details="User registered and logged in.")
            messages.success(request, "Registration successful. You are now logged in.")
            return redirect("profile")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = CustomUserCreationForm()
    return render(request, "dating_app/register.html", {"form": form})

def login_view(request):
    if request.method == "POST":
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                AuditLog.objects.create(user=user, action="login_success", ip_address=get_client_ip(request), details="User logged in successfully.")
                messages.info(request, f"Welcome back, {username}!")
                next_url = request.GET.get("next")
                return redirect(next_url) if next_url else redirect("profile")
            else:
                AuditLog.objects.create(user=None, action="login_fail", ip_address=get_client_ip(request), details=f"Failed login attempt for username: {username}")
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = CustomAuthenticationForm()
    return render(request, "dating_app/login.html", {"form": form})

def logout_view(request):
    if request.user.is_authenticated:
        AuditLog.objects.create(user=request.user, action="logout", ip_address=get_client_ip(request), details="User logged out.")
        logout(request)
        messages.info(request, "You have successfully logged out.")
    return redirect("home")

# --- Profile Views (Step 6) ---
@login_required
def profile_view(request):
    profile = request.user.profile
    return render(request, "dating_app/profile_view.html", {"profile": profile})

# Removed conditional CSRF exemption - CSRF protection is always ON
@login_required
def profile_edit(request):
    profile = request.user.profile
    if request.method == "POST":
        form = UserProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            AuditLog.objects.create(user=request.user, action="profile_update", ip_address=get_client_ip(request), details="User profile updated.")
            messages.success(request, "Your profile has been updated successfully.")
            return redirect("profile")
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = UserProfileForm(instance=profile)
    return render(request, "dating_app/profile_edit.html", {"form": form})

# --- Matching/Messaging Views (Step 7) ---
@login_required
def users_list(request):
    # Secure: Use ORM, filter as needed
    users = User.objects.exclude(id=request.user.id).select_related("profile")
    context = {"users": users}
    return render(request, "dating_app/users_list.html", context)

# Removed conditional CSRF exemption - CSRF protection is always ON for POST requests
@login_required
def like_user(request, user_id):
    if request.method == "POST":
        liked_user = get_object_or_404(User, id=user_id)
        current_user = request.user
        if liked_user == current_user:
            messages.error(request, "You cannot like yourself.")
            return redirect("users_list")
        reciprocal_like_exists = Match.objects.filter(user1=liked_user, user2=current_user).exists()
        like, created = Match.objects.get_or_create(user1=current_user, user2=liked_user)
        if reciprocal_like_exists:
            messages.success(request, f"It's a match with {liked_user.username}!")
            return redirect("matches")
        else:
            if created:
                messages.info(request, f"You liked {liked_user.username}. If they like you back, it'll be a match!")
            else:
                messages.warning(request, f"You already liked {liked_user.username}.")
            return redirect("users_list")
    else:
        # GET requests are not appropriate for state-changing actions like 'like'
        messages.error(request, "Invalid request method.")
        return redirect("users_list")

@login_required
def matches_view(request):
    current_user = request.user
    matches_initiated = Match.objects.filter(user1=current_user)
    users_liked_by_current = [match.user2 for match in matches_initiated]
    matches_received = Match.objects.filter(user2=current_user)
    users_who_liked_current = [match.user1 for match in matches_received]
    mutual_matches_users = list(set(users_liked_by_current) & set(users_who_liked_current))
    context = {"matches": mutual_matches_users}
    return render(request, "dating_app/matches_view.html", context)

@login_required
def chat_view(request, username):
    target_user = get_object_or_404(User, username=username)
    current_user = request.user
    if current_user == target_user:
        messages.error(request, "You cannot chat with yourself.")
        return redirect("users_list")
    mutual_match = Match.objects.filter(user1=current_user, user2=target_user).exists() and \
                   Match.objects.filter(user1=target_user, user2=current_user).exists()
    if not mutual_match:
        messages.error(request, f"You are not matched with {username}. Cannot initiate chat.")
        return redirect("matches")

    if request.method == "POST":
        content = request.POST.get("content")
        if content:
            # Secure: Content is saved directly. Django templates escape by default.
            # Removed conditional escaping based on ENABLE_XSS_VULNERABILITY
            Message.objects.create(sender=current_user, recipient=target_user, content=content)
            AuditLog.objects.create(user=current_user, action="message_sent", ip_address=get_client_ip(request), details=f"Message sent to {target_user.username}")
            return redirect("chat", username=username)
        else:
            messages.error(request, "Cannot send an empty message.")

    messages_history = Message.objects.filter(
        (Q(sender=current_user, recipient=target_user) | Q(sender=target_user, recipient=current_user))
    ).order_by("timestamp")
    Message.objects.filter(sender=target_user, recipient=current_user, is_read=False).update(is_read=True)

    context = {
        "target_user": target_user,
        "messages": messages_history,
        # Removed: "xss_enabled": settings.ENABLE_XSS_VULNERABILITY
    }
    return render(request, "dating_app/chat_view.html", context)


# --- Removed Vulnerability Demonstration Views (Step 8) ---
# Removed idor_vulnerability_view
# Removed sqli_vulnerability_view

